package RobotAdapter;
public interface Spieler
{

    public int geheNachLinks(int a);
    public int geheNachRechts(int a);
    public int geheNachOben(int a);
    public int geheNachUnten(int a);
}
